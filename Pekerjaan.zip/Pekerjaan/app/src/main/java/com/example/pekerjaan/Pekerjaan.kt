package com.example.pekerjaan

class Pekerjaan (
    var name: String = "",
    var deskripsi: String = "",
    var gambar: Int = 0
){
}